require.config({
    baseUrl:'./',
    paths: {

    }
})